import Cocoa

func reverseString(str:String) -> String{
    guard str.count==0 else {
        return String(str.reversed())
    }
    return ""
}
print(reverseString(str:""))

//ex2
func convertNumberToCurrency(num:Double) ->String{
return(NumberFormatter.localizedString(from: 12345678, number: .currency))
}
print(convertNumberToCurrency(num: 1000000))
//ex3
func format(num:Double) ->String{
    let thousand = num/1e3
    let million = num/1e6
    let billion = num/1e9
    if(billion>1.0){
        return "\(round(billion*10)/10)B"
    }
    if(million>1.0){
        return "\(round(million*10)/10)M"
    }
    return "\(round(thousand*10)/10)K"
}
print(format(num: 1010))
//ex3

func GCD(num:Int?,num2:Int?)->Int{
    guard (num==0 && num2==0) else {
        if(num2==0) {
            return num!
        }
        else{
            return GCD(num: num2!,num2: num!%num2!)
        }
    }
    return 0
}
print(GCD(num: 10, num2: 25))

func multiple(num:Int?, num2:Int?)->Int{
    let gcd:Int = GCD(num: num!, num2: num2!)
    if(gcd != 0){
        return num!*num2!/gcd
    }
    return 0
}
print(multiple(num: 100, num2: 8))
//ex4
var speak={(sentence:String)->Void in
        print(sentence)
}
var think={(idea:String?)->Void in
    if(idea==nil){
        print("Error")
    }else{
        speak(idea!)
    }
}
think("Call me Bi Dep Trai")
