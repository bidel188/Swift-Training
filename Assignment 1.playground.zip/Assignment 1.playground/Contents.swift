import Foundation

var str = "Hello, playground"
print(str)
//Ex1
print("=======Ex1======")
let x:Double = 10, y:Double =  55, x2:Double = 7 , y2:Double = 9
var distance:Double = sqrt((x-x2)*(x-x2)+(y-y2)*(y-y2))
print(distance)
//Ex2
print("=======Ex2======")
var n = 10
var f = 1
for i in 1...n{
    f = f * i;
}
print(f)
//ex3
print("=======Ex3======")
for i in 0...10{
    print(Double(i)/10)
}
//Labeled statement often be used in nested loop, it helps us control flow
firstLoop: for i in 1...100{
    for ii in 1...10{
        if(ii%5==0)
        {
            continue firstLoop}
    }
    for ii in 10...i{
     print(ii)
    }
}
//U see, with labeled statement we can continue to firstloop easy
print("=======Ex4======")
var ok:Bool=false
func printLog(strArray:[String])->Bool{
    if(strArray.count == 0 ) {
        return false;
    }
    for str in strArray{
        if(str.count != 0 )
        {
            ok = true
            break
        }
    }
    if(ok == true ){
        for str in strArray{
            print(str)
        }
    }
    return false
}
var strArray = ["Bi", "Dep", "Trai"]
printLog(strArray: strArray)


func fib(num:Int)->Int{
    var num1=0
    var num2=1
    for _ in 0...num{
        var temp = num2
        num2=num1+num2
        num1=temp
    }
    return num2
}

print(fib(num: 10))
print("=======Ex5======")

var dict = ["key_1":10,"key_2":213,"key_3":12,"key_4":43]
var sum={ (dict:[String:Int]) -> Int in
    var result = 0
    for(value,key) in dict{
        result += key
    }
    return result
}
print(sum(dict))
 
print("=======Ex6======")
var num:Double = 100000
if (sqrt(num)*sqrt(num)==num){
    print("It's square number")
}else{
    print("It's not square number")
}





