//======Ex1=========
//extension Int{
//    class var bound  : Int{
//        switch self {
//        case 0:
//            return 1000
//        case 1_000_000:
//            return 1000000
//        default:
//            return 9999
//        }
//    }
//}
//print(Int.zero)
//var intBound = Int.bound
//print(intBound)
//intBound = 1_000_000
//print(intBound)
//Int.bound = intBound
//intBound = Int.bound
//print(intBound)
//=======Ex2=======
enum Food :Int{
    case meat = 10
    case vegetable = 1
    case fruit = 7
    case egg = 5
    case milk = 3
}
protocol Living {
    func eat(food:Food)
    func eat(food:[Food])
}
class Animal{
    var fullStatus:Int = 0
}
class AnimalA:Animal{
//    func eat(food: Food) {
//        if (self.fullStatus >= 50 ){
//            print("Im Full, Thanks for feedfing me")
//        } else{
//            self.fullStatus += food.rawValue
//            print("Im hungry, please feed me more")
//        }
//    }
//
//    func eat(food: [Food]) {
//        if(self.fullStatus<50)
//        {
//            for eachFood in  food{
//                self.fullStatus += eachFood.rawValue
//            }
//            print("Im hungry, please feed me more")
//        }else{
//            print("Im Full, Thanks for feedfing me")
//        }
//    }
    
    var delegate:Living?
    
}
class AnimalB:Animal,Living{
    func eat(food: Food) {
        if (self.fullStatus >= 50 ){
            print("Im Full, Thanks for feedfing me")
        } else{
            self.fullStatus += food.rawValue
            print("Im hungry Cat, please feed me more")
        }
    }
    
    func eat(food: [Food]) {
            for eachFood in  food{
                if (self.fullStatus >= 50 ){
                    print("Im Full, Thanks for feedfing me")
                    return
                } else{
                    self.fullStatus += eachFood.rawValue
                    print("Im hungry Cat, please feed me more")
                }
            }
   
    }
}
let dog = AnimalA()
let cat = AnimalB()
dog.delegate = cat
dog.delegate?.eat(food: Food.egg)
dog.delegate?.eat(food: [Food.vegetable,Food.milk])

//=======Ex3======

struct Stack {
    var items = [Int]()
    mutating func peek() -> Int? {
        if( items.count > 0) {
            return items.last!
        }
        return nil
    }
    mutating func push(item: Int) {
        items.append(item)
    }
    mutating func pop() -> Int {
        return items.removeLast()
    }
    mutating func count() -> Int {
        return items.count
    }
    subscript(index:Int) -> Int{
        get{
            return items[index]
        }
        set{
            items[index] = newValue
        }
    }
}

var  st = Stack();
print(st.peek())
st.push(item: 1)
st.push(item: 10)
st.push(item: 19)
print(st.peek()!)
print(st.count())
st.pop()
print(st.count())
st[1]=100
print(st[1])
