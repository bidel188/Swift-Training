//======Ex1=========
extension Int{
    private static var value = 1000
    static var bound  : Int{
        set{
            self.value = 2000000
        }get{
            return self.value
        }
        
    }
}

print(Int.zero)
var intBound = Int.bound
print(intBound)
intBound = 1_000_000
print(intBound)
Int.bound = intBound
intBound = Int.bound
print(intBound)
//=======Ex2=======
enum Food :Int{
    case meat = 10
    case vegetable = 1
    case fruit = 7
    case egg = 5
    case milk = 3
}
protocol Living {
    func eat(food:Food)
    func eat(food:[Food])
}
class Animal{
    var fullStatus:Int = 0
}
class AnimalA:Animal{
    func eat(food: Food) {
        if((dog.delegate) != nil){
            dog.delegate?.eat(food: food)
        }else{
            if (self.fullStatus >= 50 ){
                print("Im Full, Thanks for feedfing me")
            } else{
                self.fullStatus += food.rawValue
                print("Im hungry, please feed me more")
            }
        }
    }
    
    func eat(food: [Food]) {
        if((dog.delegate) != nil)
        {
            dog.delegate?.eat(food: food)
        }else{
            if(self.fullStatus<50)
            {
                for eachFood in  food{
                    self.fullStatus += eachFood.rawValue
                }
                print("Im hungry, please feed me more")
            }else{
                print("Im Full, Thanks for feedfing me")
            }
        }
    }
    
    var delegate:Living?
    
}
class AnimalB:Animal,Living{
    func eat(food: Food) {
        if (self.fullStatus >= 50 ){
            print("Im Full, Thanks for feedfing me")
        } else{
            self.fullStatus += food.rawValue
            print("Im hungry Cat, please feed me more")
        }
    }
    
    func eat(food: [Food]) {
        for eachFood in  food{
            if (self.fullStatus >= 50 ){
                print("Im Full, Thanks for feedfing me")
                return
            } else{
                self.fullStatus += eachFood.rawValue
                print("Im hungry Cat, please feed me more")
            }
        }
        
    }
}
let dog = AnimalA()
let cat = AnimalB()
dog.delegate = cat
dog.eat(food: Food.egg)
dog.eat(food: [Food.vegetable,Food.milk])

//=======Ex3======

class Stack<T> {
    var items : [T]!
    init(){
        self.items=[]
    }
    public func peek()->T?{
        if(self.items.count>0){
            return self.items[0]
        }
        return nil
    }
    public func push(element:T){
        self.items.insert(element, at: 0)
    }
    public func pop() -> T?{
        if(self.items.count>0){
            return self.items.remove(at: 0)
        }
        return nil
    }
    public func count() -> Int{
        return self.items.count
    }
    subscript(index:Int)->T?{
        get{
            
            if(self.items.count-1 >= index) {
                return self.items[index]
            }else{
                return nil
            }
        }set{
            if(self.items.count - 1 >= index) {
                self.items[index] = newValue!
            }
        }
    }
}

var  st = Stack<Int>()
print(st.peek())
st.push(element: 1)
st.push(element: 10)
st.push(element: 19)
print(st.peek()!)
print(st.count())
st.pop()
print(st.count())
st[1]=100
print(st[1]!)
